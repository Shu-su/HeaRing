import json
import boto3
import paho.mqtt.client as mqtt
import time

# DynamoDB 리소스 설정
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('gpssession')
# API Gateway Management API 클라이언트 설정
apigateway = boto3.client('apigatewaymanagementapi', endpoint_url="https://9fnk3gtqti.execute-api.ap-northeast-2.amazonaws.com/production/")

# MQTT 클라이언트 설정
mqtt_client = mqtt.Client()
mqtt_client.connect("43.202.38.206", 1883, 60)
mqtt_client.loop_start()  # MQTT 클라이언트 비동기 실행

def lambda_handler(event, context):
    print("이벤트:", json.dumps(event))  # event 객체의 전체 구조 확인

    route_key = event['requestContext']['routeKey']
    connection_id = event['requestContext']['connectionId']
    
    # $connect와 $disconnect 요청에 대해 먼저 처리
    if route_key == '$connect':
        return handle_connect(connection_id)
    elif route_key == '$disconnect':
        return handle_disconnect(connection_id)
    elif route_key == '$default':
        return handle_default(event, connection_id)
    else:
        body = event.get('body', None)
        if body:
            body = json.loads(body)  # body가 JSON 형식이라면 파싱
            print(f"Parsed body: {body}")
            action = body.get('action', None)
            print(f"Action from body: {action}")
            if action == 'sendLocation':
                return handle_send_location(body)
        else:
            action = None  # body가 없으면 action도 None
    
    return {
        'statusCode': 400,
        'body': 'Invalid route or action'
    }

def handle_connect(connection_id):
    # 연결된 세션을 DynamoDB에 등록
    table.put_item(Item={'connectionId': connection_id})
    return {'statusCode': 200, 'body': 'Connected'}

def handle_disconnect(connection_id):
    # clientId가 'ANDROID'인 항목을 조회하여 연결 종료 시 'stop' 명령을 MQTT로 게시
    response = table.query(
        IndexName="clientId--index",  # GSI 이름
        KeyConditionExpression="clientId = :c",  # clientId가 파티션 키인 GSI
        ExpressionAttributeValues={':c': "ANDROID"}
    )

    # ANDROID 클라이언트에 대해서만 'stop' 명령 게시
    for item in response['Items']:
        if item['connectionId'] == connection_id:
            print("Publishing 'stop' to MQTT for ANDROID...")
            mqtt_client.publish("raspberry/control", "stop")  # "stop" 명령을 MQTT로 게시
            break

    # 연결 종료 후 세션 삭제 (ANDROID, RASPBERRY 클라이언트 모두 처리)
    table.delete_item(Key={'connectionId': connection_id})

    return {'statusCode': 200, 'body': 'Disconnected'}


def handle_default(event, connection_id):
    body = json.loads(event['body'])
    client_id = body.get("clientId")
    print(f"client_id: {client_id}")  # 디버깅용 로그

    if client_id == "ANDROID":
        # 안드로이드 클라이언트가 연결되면 "start" 명령을 MQTT로 게시
        table.update_item(
            Key={'connectionId': connection_id},
            UpdateExpression="set clientId = :c",
            ExpressionAttributeValues={':c': client_id}
        )
        print("Publishing 'start' to MQTT...")  # 디버깅용 로그
        mqtt_client.publish("raspberry/control", "start")

    elif client_id == "RASPBERRY":
        # 라즈베리 클라이언트가 연결되면 해당 세션을 등록
        table.update_item(
            Key={'connectionId': connection_id},
            UpdateExpression="set clientId = :c",
            ExpressionAttributeValues={':c': client_id}
        )

    return {'statusCode': 200, 'body': 'Client ID registered'}

def handle_send_location(body):
    # body에서 위치 데이터 추출
    latitude = body.get('latitude')
    longitude = body.get('longitude')

    location_data = {
        "latitude": latitude,
        "longitude": longitude
    }

    # GSI를 사용하여 clientId가 ANDROID인 세션(connectionId) 조회 
    response = table.query(
        IndexName="clientId--index",  # GSI 이름
        KeyConditionExpression="clientId = :c",  # clientId가 파티션 키인 GSI
        ExpressionAttributeValues={':c': "ANDROID"}
    )

    # response가 비어있지 않다면 connectionId를 가져와서 WebSocket으로 전송
    if response['Items']:
        for item in response['Items']:
            connection_id = item['connectionId']

            # WebSocket을 통해 위치 데이터 전송
            try:
                apigateway.post_to_connection(
                    Data=json.dumps(location_data),
                    ConnectionId=connection_id
                )
            except apigateway.exceptions.GoneException:
                print(f"Connection ID {connection_id} is no longer active.")
                # 연결이 닫혔을 때 처리할 로직을 추가할 수 있습니다.
                table.delete_item(Key={'connectionId': connection_id})  # 세션 삭제
    else:
        print("No active session for clientId 'ANDROID'.")
        # 추가적인 처리가 필요하다면 여기에 구현할 수 있습니다.

    return {'statusCode': 200, 'body': 'Location data sent'}


