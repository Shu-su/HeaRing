import json
import boto3
import requests
from datetime import datetime

# S3 클라이언트 초기화
s3_client = boto3.client('s3')

# POST 요청을 보낼 API URL
api_url = 'http://ec2-43-202-38-206.ap-northeast-2.compute.amazonaws.com:8080/api1/recordings/recording'

def lambda_handler(event, context):
    # S3 이벤트에서 버킷 이름과 객체 키 추출
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    object_key = event['Records'][0]['s3']['object']['key']

    # .mp3 파일만 처리
    if not object_key.endswith('.mp3'):
        return {
            'statusCode': 200,
            'body': json.dumps('Not an mp3 file, skipping.')
        }
    
    try:
        # S3 객체에서 메타데이터 추출
        response = s3_client.head_object(Bucket=bucket_name, Key=object_key)

        print("Metadata Response:", response['Metadata'])
        
        # 메타데이터 추출
        latitude = response['Metadata'].get('latitude')
        longitude = response['Metadata'].get('longitude')
        recording_time = response['Metadata'].get('recording_time')
        
        print(f"추출된 메타데이터값 - Latitude: {latitude}, Longitude: {longitude}, Recording Time: {recording_time}")
        
        # 객체 URL 생성
        object_url = f'https://{bucket_name}.s3.amazonaws.com/{object_key}'

        # 요청 데이터 생성
        data = {
            "deviceId": 2,
            "filepath": object_url,
            "timestamp": recording_time,
            "latitude": latitude,
            "longitude": longitude
        }

        print("request data:", data)

        # POST 요청 보내기
        response = requests.post(api_url, json=data)

        if response.status_code == 200:
            print(f"POST request successful. Response: {response.status_code}, {response.text}")
        else:
            print(f"POST request failed. Response: {response.status_code}, {response.text}")
        
        return {
            'statusCode': 200,
            'body': json.dumps('데이터가 성공적으로 추출되었습니다.')
        }
    
    except Exception as e:
        print(f"Error processing file {object_key}: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps('데이터추출 및 엔드포인트 호출에 실패했습니다.')
        }
